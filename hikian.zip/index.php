<?php 
session_start();
// include('mailchimp/MailChimp.php'); 
// include('mailchimp/Batch.php'); 
// include('mailchimp/Webhook.php'); 

// use \DrewM\MailChimp\MailChimp;
// $MailChimp = new MailChimp('b029f16e2f9f7504b15dd5e6750ea10b-us15');

// if ($MailChimp->success()) {
//   print_r($result); 
// } else {
//   echo $MailChimp->getLastError();
// }

// $list_id = '400c6018ab';

// $result = $MailChimp->post("lists/$list_id/members", [
//         'email_address' => 'sajeel.siddiqui93@gmail.com',
//         'status'        => 'subscribed',
//       ]);

// print_r($result);

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,height=device-height,initial-scale=1.0"/>

<meta property="og:url"  content="http://www.esurat.co.in/hikian" />
<meta property="og:type"  content="article" />
<meta property="og:title" content="Hikian is coming" />
<meta property="og:description" content="Can't wait for @Hikian to launch. I'll be eating good #rawhoney soon! Go get your own discount code form www.hikian.com" />
<meta property="og:image" content="http://esurat.co.in/hikian/images/hikian-raw-honey.png" />

<title>Hikian is coming</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />


 	
<!-- 	<script src="//code.jquery.com/jquery-1.12.4.js"></script>
  	<script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
	<script src="js/bootstrap.js"></script> 
	<!-- <script type="text/javascript" src="http://connect.facebook.net/en_US/all.js"></Script> -->
</head>
<body>


      <div class="bg-img">
      <div class="container">
        

        <div class="col-md-12">
        <div class="row">
        <div id="header-text">
        <h1 class="h-h1">HARRY'S IS COMING </h1>
        <h3 class="h-h3">RESPECTING THE FACE AND WALLET<br> SINCE LIKE...RIGHT NOW.</h3>
        </div>
       </div>

        </div>

        </div>
      </div>
      
    <div class="container" id="subscribe">
    <div class="col-md-12">

    <div class="col-md-6" id="content2">
       <h3 class="h-h4"> BE THE FIRST TO KNOW </h3>

				<form action="mailchimp.php" method="post" role="form">
					<div class="col-md-12 col-sm-12" id="form-style" style="display:flex;">
            <input name="email" type="email" class="form-control" required="required" placeholder="Enter Email" id="email">
            <button type="submit" name="submit" class="btn btn-default" id="linky">STEP INSIDE</button>
          </div>
				</form>

    </div>

    
		
    </div>
    </div>

    <?php if(isset($_SESSION['error_msg'])) { ?>
      <div class="alert alert-danger" style="text-align: center;">
       <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']); ?>
     </div>.
    <?php }?>
	
	
	
    
   
 </body>
 </html>
    