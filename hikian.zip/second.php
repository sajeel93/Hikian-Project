<?php 
   session_start();

  ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,height=device-height,initial-scale=1.0"/>

<meta property="og:url"  content="http://www.esurat.co.in/hikian" />
<meta property="og:type"  content="article" />
<meta property="og:title" content="Hikian is coming" />
<meta property="og:description" content="Can't wait for @Hikian to launch. I'll be eating good #rawhoney soon! Go get your own discount code form www.hikian.com" />
<meta property="og:image" content="http://esurat.co.in/hikian/images/hikian-raw-honey.png" />

<title>Hikian is coming</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />


  
 <script src="//code.jquery.com/jquery-1.12.4.js"></script>
    <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="js/bootstrap.js"></script> 
  <!-- <script src="js/script.js"></script>  -->
  <!-- <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script> -->
  <script type="text/javascript" src="http://connect.facebook.net/en_US/all.js"></Script>
</head>
<body>

    <div id="header_nav">
    <div class="container">
    <div class="row">
    
    <div class="col-md-12">
    <h2><strong>HARRY'S</strong> &nbsp THANK YOU FOR SIGNING UP</h2>


    </div>
    </div>
    </div>
    </div>

      <div class="bg-img2">
      <div class="container">
        

        <div class="col-md-12">
        <div class="row">

        <div class="col-md-6">
        <div id="header-text">
        <h1 class="slider-h1">SHAVING IS <br> EVOLVING </h1>
        </div>
        </div>
		
        <div class="col-md-6">
        <div id="header-right">
        <h5>DON'T LEAVE YOUR FRIENDS BEHIND</h5>
        <h2>INVITE FRIENDS & <br> EARN PRODUCT</h2>
        <p>Share your unique link via email, Facebook <br> or Twitter and earn Harry's goods for<br> each friend who signs up.</p>

        <input type="text" placeholder="http://prelaunch.harrys.com/?ref=id825664di">
        <br><br><br>
        <div class="social">
        <a class="linkz linky" href="https://www.facebook.com/dialog/share?app_id=405858656428158&display=popup&href=http://www.hikian.com/Test/&redirect_uri=http://www.hikian.com/Test/success.php" id="share_btn" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" name="discount"><img src="images/icons/fb-art.png" class="fb" width="60px"></a>
        <?php $text = urlencode("Can't wait for @Hikian_Official to launch.
I'll be eating good #rawhoney soon!
Go get your own discount code form www.hikian.com"); ?>
        <a class="linkz linkx" href="https://twitter.com/intent/tweet?text=<?php echo($text);  ?>"  id="share_btn" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" name="discount"><img src="images/icons/twitter-128.png" class="twitter" width="60px"></a>
        </div>
        </div>
        </div>

        </div>
        </div>

        </div>
      </div>
	  
	  <?php if(isset($_SESSION['success_msg'])) { ?>
      <div class="alert alert-success" style="text-align: center;">
       <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']); ?>
     </div>.
    <?php }?>

      <div class="clear"></div>

    <div id="socond-content">
      
    <div class="container">
    <div class="col-md-12">
    <div class="col-md-6" id="content">
       <h3 class="h-h4"> HERE'S HOW IT WORKS: </h3> 
    </div>
    </div>

    <div class="col-md-12 section2">
      <div class="col-md-3 first-side">
         <h5> FRIENDS JOINED </h5> 
         <hr>
         <h5> HARRY'S PRODUCT </h5>
      </div>

      <div class="col-md-2 second-side">
         <a href="#" class="number">5</a>
         <hr>
         <h5> Shave <br> Cream </h5>
      </div>


      <div class="col-md-2 second-side">
         <a href="#" class="number">10</a>
         <hr>
         <h5> Truman Handle <br> w/ Blade </h5>
      </div>

      <div class="col-md-2 second-side">
         <a href="#" class="number">25</a>
         <hr>
         <h5> Winstom <br> Shave Set </h5>
      </div>

      <div class="col-md-3 second-side">
         <a href="#" class="number">50</a> 
         <hr>
         <h5> One Year <br> Free Blades </h5>
      </div>
    </div>

    <div class="col-md-12">
    <div id="content-footer">
       <h5> <strong>No</strong> friends have joined...Yet!</h5> 
       <p>Keep checking</p>
    </div>
    </div>

    <div class="col-md-12">
    <div id="footer">
       <h5> We Skip to the US (& Canada Soon)</h5> 
    </div>
    </div>
    
    </div>
    </div>
    
   
 </body>
 </html>


    