(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=1764021290555043";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

$('.linky').click(function (e) {	
    e.preventDefault();

	FB.init({

		  	frictionlessRequests: true,
		  	init: true,
		  	level: "debug",
		  	signedRequest: null,
		  	status: true,
		  	viewMode: "website",
		  	autoRun: false,
			appId: '1764021290555043',

    });
	

 FB.ui({
	  method: 'feed',
	  name: 'Hikian is coming',
	  link: 'http://www.hikian.com',
	  picture:'http://www.hikian.com/images/hikian-raw-honey.png',
	  display: 'popup',
	  caption: 'http://www.hikian.com',
	  description:'Can\'t wait for @Hikian to launch. I\'ll be eating good #rawhoney soon! Go get your own discount code form www.hikian.com',

	}, function(data) {

				
			if(data && data.post_id) {
			var email = $('#email').val();
			var data='email=' + email;
			console.log(email);
					
			
			
			 $.ajax({
					 data: data,
					 type: "post",
					 url: "savefile.php",
					 success: function(data){


						 
						console.log(data);


					
						 
					 }
			});

		} else {
			alert("not sent");  
		}
 	});

	

});
//document.getElementById('share_btn').addEventListener('click', function() {
	$('.linkx').click(function (e) {
    e.preventDefault();
 window.open("http://twitter.com/share?url=[http://www.hikian.com]&via=hikian&image-src=[http://www.hikian.com/images/hikian-raw-honey.png]&text=[Can\'t wait for @Hikian_Official to launch. I\'ll be eating good #rawhoney soon! Go get your own discount code form www.hikian.com]");	
	
});	

function twitter()
	{
		 window.open("http://twitter.com/share?url=[http://www.hikian.com]&via=hikian&image-src=[http://www.hikian.com/images/hikian-raw-honey.png]&status=[Can\'t wait for @Hikian to launch. I\'ll be eating good  soon! Go get your own discount code form www.hikian.com]");
	}