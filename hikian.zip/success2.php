﻿<?php 
session_start();

if(isset($_SESSION['email'])){
	
	//Email information
	  $admin_email = "info@hikian.com";
	  $email = $_SESSION['email'];
	  $subject = 'Discount Coupon from Hikian';
	  $messages ="Thank You for Signing Up, \r\n";
 		$messages.="Please find your coupon code below \r\n \r\n";
		$messages.="Hikian2017 \r\n \r\n \r\n";
		$messages.="We will be notifying you when the actual shop is open and you can get your 10% discount! \r\n \r\n";
		$messages.="Kind Regards, \r\n";
		$messages.="Hiki채n Team \r\n \r\n";
		$messages.="Hiki채n is family owned company with deep respect towards bees and their products.";
		
		
		$message = wordwrap($messages);
		$message = str_replace("\n", "\r\n", $message);
	  
	  //send email
	  $mail =  mail($email, "$subject", $messages, "From:" . $admin_email);
	  
	  $text = urlencode("Can't wait for @Hikian_Official to launch.
I'll be eating good #rawhoney soon!
Go get your own discount code form www.hikian.com");
	  // $_SESSION['success_msg'] = "Thank You For Twitter Sharing"; 
	  header('location: https://twitter.com/intent/tweet?text='. $text . '');
	  exit;
    
}

?>