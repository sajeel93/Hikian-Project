<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{

	//check if its an ajax request, exit if not
	if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
	
		//exit script outputting json data
		$output = json_encode(
		array(
			'type'=>'error', 
			'text' => 'Request must come from Ajax'
		));
		
		die($output);
	} 
	
	

	if( ($_POST['email']) || ($_POST['email']!=="") )
	{
		//Sanitize input data using PHP filter_var().
		$useremail=filter_var(trim($_POST["email"]), FILTER_SANITIZE_STRING);

		$date = date('m/d/Y h:i:s a', time());
		
		$email= $date;
		$email.= ',';
		$email.= $useremail;

	
		$myfile = file_put_contents('logs.csv', $email.PHP_EOL , FILE_APPEND | LOCK_EX);
		
		
		// MAIL TO USER STARTS //
		$to   	= $useremail; //Replace with recipient email address
		
		$subject = "Discount Coupon from Hikian";
		
		$messages ="Thank You for Signing Up, <br /><br />";
 		$messages.="Please find your coupong code below <br />";
		$messages.="<b>Hikian2017</b> <br /><br />";
		$messages.="We will be notifying you when the actual shop is open and you can get your 10% discount! <br /><br />";
		$messages.="Kind Regards, <br />";
		$messages.="Hikiän Team <br /><br />";
		$messages.="Hikiän is family owned company with deep respect towards bees and their products.";
		
		
		$message = wordwrap($messages);
		$message = str_replace("\n", "\r\n", $message);

		//proceed with PHP email.
		$headers = 'From: www.hikian.com <sajeel@7koncepts.com>' . "\r\n" .
		'Reply-To: sajeel@7koncepts.com\r\n' .
		'X-Mailer: PHP/' . phpversion();
		$headers.= "MIME-version: 1.0\n";
		$headers.= "Content-type: text/html; charset= iso-8859-1\n";

		
		//MAIL TO USER ENDS //
		
		
		//MAIL TO OWNER STARTS //
		$my_subject="New Signup on Hikian";
		$my_message="New signup on Hikain by <br />" .$useremail;
		$my_mail="sajeel@7koncepts.com";
		
		//proceed with PHP email.
		$o_headers = 'From: New Signup<'.$useremail.'>' . "\r\n" .
		'Reply-To: '. $useremail .'\r\n' .
		'X-Mailer: PHP/' . phpversion();
		$o_headers.= "MIME-version: 1.0\n";
		$o_headers.= "Content-type: text/html; charset= iso-8859-1\n";		
		//MAIL TO OWNER END //
	
		
		$sentMail = mail($to, $subject, $message, $headers);
		$sentMail = true;
		
		
		if(!$sentMail)
	
		{
			$output = json_encode(array('type'=>'error', 'text' => 'Could not send mail! Please contact administrator.'));
			die($output);
		} 
			else
		{
			$rcvMail = mail($my_mail, $my_subject, $my_message, $o_headers);
		}

		
	
	}
	
	

}
?>