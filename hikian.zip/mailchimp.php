<?php 
session_start();

$mailchimpApiKey = "b029f16e2f9f7504b15dd5e6750ea10b-us15";
$mailchimpListId = "400c6018ab";

include('mailchimp/MailChimp.php'); 
include('mailchimp/Batch.php'); 
include('mailchimp/Webhook.php'); 

use \DrewM\MailChimp\MailChimp;

if(isset($_POST['email'])){
  $email = $_POST['email'];

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {

        $MailChimp = new MailChimp($mailchimpApiKey);

		$result = $MailChimp->post("lists/$mailchimpListId/members", [
		        'email_address' => $_POST['email'],
		        'status'        => 'subscribed',
		      ]);
  //       var_dump($result);
           $result=true;
		  if($result) {
		$_SESSION['email'] = $_POST['email'];
        	header('location: thankyou.php');
		} 
		else {
			
			$_SESSION['error_msg'] = "already subscribed or failed to please try again";
			header('location: index.php');
		}
    }  
	else {
		$_SESSION['error_msg'] = "$email is not a valid email address";
		header('location: index.php');
	}
	
	
    
}

exit;